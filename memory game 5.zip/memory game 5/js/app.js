//function run when load page
$(function(){

  /*
  create variables
  */

 //Handle first and second card clicked
 let clickedCard1='';
 let clickedCard2='';
 //store number of attempts
 let atmp=0;
 //store second of timer
 let second=0;
 //game interval do input method every 1 second
 let game_interval = setInterval(gameInterval,1000);
 //store status of clicked card is close or not
 let isClickedCardsClose=true;
 //store status of load all symbols then close and start games
 let isStartGame = false;

 /*
 - create 8 objects of sybmols
 - object contains id , symbol and color
 - id : name of id set to card div
 - symbol: class name from fontawsome to get symbol
 - color: symbol color to change default color
 */
 let crow = Object();
 crow.id="crow";
 crow.symbol="fas fa-crow";
 crow.color="red";
 let cat = Object();
 cat.id = "cat";
 cat.symbol ="fas fa-cat";
 cat.color="darkgreen";
 let fish = Object();
 fish.id = "fish";
 fish.symbol ="fas fa-fish";
 fish.color="blue";
 let spider = Object();
 spider.id = "spider";
 spider.symbol ="fas fa-spider";
 spider.color="black";
 let apple = Object();
 apple.id = "apple";
 apple.symbol ="fas fa-apple-alt";
 apple.color="darkred";
 let carrot = Object();
 carrot.id = "carrot";
 carrot.symbol ="fas fa-carrot";
 carrot.color="orange";
 let lemon = Object();
 lemon.id = "lemon";
 lemon.symbol ="far fa-lemon";
 lemon.color="yellow";
 let seedling = Object();
 seedling.id = "seedling";
 seedling.symbol ="fas fa-seedling";
 seedling.color="green";

 //create symboles array
 let symbols =[crow,cat,fish,spider,apple,carrot,lemon,seedling];

 //set symbols id to 16 cards div randomly when load game
 //random number between 0 to 15 (16 crads) without repeating
 let randomNumber = generateNumber([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]);
 //loop symbols array
 for(let i=0 ; i<symbols.length ; i++){ 
     //get symbol  by array index
     let symbol = symbols[i];
     //get two index numbers randomly (from 0 to 15)
     let index1 = randomNumber.next().value;
     let index2 =randomNumber.next().value;
     //get two cards div by index randomly (from 0 to 15)
     let card1 = $('.game_board').children().eq(index1);
     let card2 = $('.game_board').children().eq(index2);
     //change cards id to symbols id
     card1.attr('id',symbol.id);
     card2.attr('id',symbol.id);
     //change symbols
     card1.find('i').attr('class',symbol.symbol);
     card2.find('i').attr('class',symbol.symbol);
     //change colors
     card1.find('i').css('color',symbol.color);
     card2.find('i').css('color',symbol.color);

 }

    //after load all symbols
    //close all cards
    closeAllCards();

    //set up result popup window
    //create dialog from result div
    //get device screen width
    let screenWidth = window.screen.width;
    //check device to responsive dialog
    //desktop
    if(screenWidth > 800){
    $("#result_popup").dialog({
    autoOpen:false,
    modal:true,
    title: "Result",
    width:500,
    height:400,
    open: function( event, ui ) {
    }
    });
   }//mobile
    else{
    $("#result_popup").dialog({
    autoOpen:false,
    modal:true,
    title: "Result",
    width:200,
    height:270,
    open: function( event, ui ) {
    }
    });
    }

 //---------------------------------------------------------------------

    /*
   Listeners
   */
   $(document).on('click', '.cards', function(event) {
       //check if clicked cards is close before do new listener
       //and clicked card symbol close (symbol is question mark)
       if(isClickedCardsClose && $(this).find('i').attr('class') == "fas fa-question"){
         //get symbol by card id
         let clickedSymbol = getSymbolByID($(this).attr('id'));
         //set symbol to card
         $(this).find('i').attr('class',clickedSymbol.symbol);
         //change card color
         $(this).find('i').css('color',clickedSymbol.color);
         //check if clicked card is first or second
         //first clicked
         if(clickedCard1 == ''){
            //set to variable
            clickedCard1 = $(this);
         }
          //second clicked
          else{
           //set to variable
            clickedCard2 = $(this);
           //check if first clicked card symbol equal second card symbol
            let firstSymbol =  clickedCard1.find('i').attr('class');
            let secondSymbol = clickedCard2.find('i').attr('class');
            if(firstSymbol == secondSymbol){
                //increment number of attempts
                increment_attempt();
                //reset clicked cards
                clickedCard1='';
                clickedCard2='';
            }//not same symbol
             else{
              //close cards
              close_clickedCards();
             }

          }
        }
    });


   /*
    function run every second:
    - update timer.
    - check if player open all cards and win.
   */
   function gameInterval(){
     //update timer
     second = second + 1;
     let time = "Time: "+getTime(second);
     $('#time').text(time);

     //check if player win
     if(isWin() && isStartGame){
      //stop game interval
      clearInterval(game_interval);
      //set result values
      //set time
      $('#time2').text(time);
      //set attempts
      $('#attempts2').text("Number of attempts: "+atmp);
      //check number of attempts
      if(atmp <= 10)
         //set img src 3 star
         $("#star").attr('src',"img/star3.png");
      else if(atmp >=11 && atmp <=13)
         //set img src 2 star
         $("#star").attr('src',"img/star2.png");
      else if(atmp >=14 && atmp <=16)
         //set img src 1 star
         $("#star").attr('src',"img/star1.png");
      else if(atmp>=17)
         //set img src 0 star
         $("#star").attr('src',"img/star0.png");
        //open result dialog
        showResult();
     }
 }

   //---------------------------------------------------------------------

   /*
   Help functions
   */

   //incremnt Number of attempts and update text
   function increment_attempt(){
     atmp++;
     $("#attempts").text("Number of attempts: "+atmp);
     }

    //get symbol object by input id
    function getSymbolByID(id){
      //loop on symbol array
      for(let i=0 ; i<symbols.length ; i++){
          //get current symbol by index
          let symbol = symbols[i];
          //get symbol id
          let symbol_id = symbol.id;
          //check if input id equal current symbol id
          if(symbol_id == id){
             //return found symbol
             return symbol;
          }
         }
    }

   //close clicked cards
   function close_clickedCards(){
       //set close false
       isClickedCardsClose=false;
      //time out: delay 1 second then close cards
      setTimeout(function(){
         //increment number of attempts
         increment_attempt();
         //close cards
         //set question symbol
         clickedCard1.find('i').attr('class','fas fa-question');
         clickedCard2.find('i').attr('class','fas fa-question');
         //change symbol color
         clickedCard1.find('i').css("color","#8B6F53");
         clickedCard2.find('i').css("color","#8B6F53");
         //reset clicked cards
         clickedCard1='';
         clickedCard2='';
         //set close true after close cards
          isClickedCardsClose=true;
         }, 1000);
    }


 //close all cards when load game
 function closeAllCards(){
  //delay 2 seconds then close cards when start games
  setTimeout(function(){
  $(".cards").each(function(){
         //set question symbol
         $(this).find('i').attr('class','fas fa-question');
         $(this).find('i').attr('class','fas fa-question');
         //change symbol color
         $(this).find('i').css("color","#8B6F53");
         $(this).find('i').css("color","#8B6F53");
   });
   //change start of game after close all
   isStartGame=true;
      }, 2000);
}

  //check if all cards is open
  //return true if all cards open
   function isWin(){
   let is =true;
  //loop on cards and check if any card close
  $(".cards").each(function(){

    if($(this).find('i').attr('class') == "fas fa-question"){
        is =false;
    }

   });
    return is;
}

  //input updated second and get new time
  function getTime(second) {
    let hours = Math.floor(second / 3600);
    second = second % 3600;
    let minutes = Math.floor(second / 60);
    second = second % 60;
    let seconds = Math.floor(second);
    hours = numberFormat(hours);
    minutes = numberFormat(minutes);
    seconds = numberFormat(seconds);

    let time = hours + ":" + minutes + ":" + seconds;
    return time;
    }

    //input number and get format two digit
    function numberFormat(number) {
     if(number <10 ){
         return "0" + number;
     }
     else{
        return number;
     }
  }

    //open result dialog
    function showResult(){
     $('#result_popup').empty();
     //clone result div
     let resultClone=$("#result").clone();
     //change visibility of result div from hidden to visible
     resultClone.css("visibility", "visible");
     //append result div to dialog
     $('#result_popup').append(resultClone);
     //open dialog
     $('#result_popup').dialog('open');
    }

  //Generate random number Without Repeating from input array
  //The yield keyword is used to pause and resume a generator function (function*)
  function* generateNumber(numbersArray) {
    var i = numbersArray.length;
    while (i--) {
        yield numbersArray.splice(Math.floor(Math.random() * (i+1)), 1)[0];
    }
  }





});
